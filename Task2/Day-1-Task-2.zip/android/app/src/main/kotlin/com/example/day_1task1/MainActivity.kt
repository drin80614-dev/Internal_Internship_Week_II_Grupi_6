package com.example.day_1task1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
