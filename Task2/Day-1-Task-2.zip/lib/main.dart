import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AverageApp(),
    );
  }
}

class AverageApp extends StatefulWidget {
  const AverageApp({super.key});

  @override
  State<AverageApp> createState() => _AverageAppState();
}

class _AverageAppState extends State<AverageApp> {
  final TextEditingController n1 = TextEditingController();
  final TextEditingController n2 = TextEditingController();
  final TextEditingController n3 = TextEditingController();

  String result = "";

  void calculateAverage() {
    if (n1.text.isEmpty || n2.text.isEmpty || n3.text.isEmpty) {
      setState(() {
        result = "Ju lutem plotësoni të gjitha fushat!";
      });
      return;
    }

    double? num1 = double.tryParse(n1.text);
    double? num2 = double.tryParse(n2.text);
    double? num3 = double.tryParse(n3.text);

    if (num1 == null || num2 == null || num3 == null) {
      setState(() {
        result = "Ju lutem shkruani vetëm numra valid!";
      });
      return;
    }

    double avg = (num1 + num2 + num3) / 3;

    String status = avg >= 5 ? "Kalon" : "Duhet përmirësim";

    setState(() {
      result = "Mesatarja: ${avg.toStringAsFixed(2)}\nStatusi: $status";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Average Calculator"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: n1,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Nota 1",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: n2,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Nota 2",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: n3,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Nota 3",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: calculateAverage,
              child: const Text("Llogarit Mesataren"),
            ),
            const SizedBox(height: 20),
            Text(
              result,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
