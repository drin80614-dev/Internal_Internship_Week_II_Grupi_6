import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: GradeCalculator(),
    );
  }
}

class GradeCalculator extends StatefulWidget {
  const GradeCalculator({super.key});

  @override
  State<GradeCalculator> createState() => _GradeCalculatorState();
}

class _GradeCalculatorState extends State<GradeCalculator> {
  final TextEditingController n1 = TextEditingController();
  final TextEditingController n2 = TextEditingController();
  final TextEditingController n3 = TextEditingController();

  String result = "";
  String status = "";

  void calculate() {
    if (n1.text.isEmpty || n2.text.isEmpty || n3.text.isEmpty) {
      setState(() {
        result = "Plotëso të gjitha fushat!";
        status = "";
      });
      return;
    }

    double? a = double.tryParse(n1.text);
    double? b = double.tryParse(n2.text);
    double? c = double.tryParse(n3.text);

    if (a == null || b == null || c == null) {
      setState(() {
        result = "Shkruaj vetëm numra!";
        status = "";
      });
      return;
    }

    double avg = (a + b + c) / 3;

    setState(() {
      result = "Mesatarja: ${avg.toStringAsFixed(2)}";

      if (avg >= 5) {
        status = "Status: KALON ✅";
      } else {
        status = "Status: DUHET PËRMIRËSIM ❌";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Grade Calculator"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: n1,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Nota 1"),
            ),
            TextField(
              controller: n2,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Nota 2"),
            ),
            TextField(
              controller: n3,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Nota 3"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: calculate,
              child: const Text("Llogarit mesataren"),
            ),
            const SizedBox(height: 20),
            Text(
              result,
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 10),
            Text(
              status,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
